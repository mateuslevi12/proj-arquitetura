import { Pedido } from "./pedido";

export class Cliente {
    nome: string;
    endereco: string;
    telefone: string;
    pedidos: Pedido[]

    constructor(data: Partial<Cliente>) {
        this.nome = data.nome || '';
        this.endereco = data.endereco || '';
        this.telefone = data.telefone || '';
        this.pedidos = data.pedidos || [];
    }

    adicionarPedido(pedido: Pedido): void {
        this.pedidos.push(pedido);
    }
}