export class Ingrediente {
    nome: string
    quantidade: string

    constructor(nome: string, quantidade: string) {
        this.nome = nome;
        this.quantidade = quantidade;
    }

}