import { Cliente } from "./cliente"
import { Pizza } from "./pizza"

export class Pedido {
    numero: number
    cliente: Cliente
    private pizzas: Pizza[] = []
    valorTotal: number

    constructor(data: Partial<Pedido>) {
        this.numero = data.numero || 0,
            this.cliente = data.cliente || new Cliente({
                endereco: '',
                telefone: '',
                pedidos: [],
                nome: ''
            }),
            this.valorTotal = data.valorTotal || 0
    }

    adicionarProduto(pizza: Pizza) {
        this.pizzas.push(pizza)
    }
}