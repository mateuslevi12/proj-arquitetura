import { Ingrediente } from "./ingrediente";

export class Pizza {
    id?: number
    sabor: string;
    private ingredientes: Ingrediente[] = [];
    valor: number;
    tamanho: string;

    constructor(data: Partial<Pizza>) {
        this.id = data.id;
        this.sabor = data.sabor || '';
        this.valor = data.valor || 0;
        this.tamanho = data.tamanho || '';
    }

    adicionarIngrediente(ingrediente: Ingrediente): void {
        this.ingredientes.push(ingrediente);
    }

}
