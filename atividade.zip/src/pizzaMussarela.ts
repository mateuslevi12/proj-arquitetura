import { Ingrediente } from "./ingrediente";
import { Pizza } from "./pizza";

export class PizzaMussarela extends Pizza {
    constructor(tamanho: string, sabor: string, ) {
        super({
            tamanho,
            sabor,
            ingredientes: [],
            valor: 0
        });
      
      }
}