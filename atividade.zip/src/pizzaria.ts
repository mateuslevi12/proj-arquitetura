import { Pizza } from "./pizza";

export class Pizzaria {
    nome: string;
    endereco: string;
    telefone: string;
    menu: Pizza[];

    constructor(data: Partial<Pizzaria>) {
        this.endereco = data.endereco || '';
        this.telefone = data.telefone || '';
        this.menu = data.menu || [];
        this.nome = data.nome || "Pizzaria Default";
    }

    adicionarPizza(pizza: Pizza) {
        this.menu.push(pizza);
    }

    toString(): string {
        return this.menu.map(i => i.toString()).join(', ');
    }
}